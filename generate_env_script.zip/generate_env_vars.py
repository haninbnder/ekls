# generate_env_vars.py

import re
from pathlib import Path

settings_path = Path(__file__).parent / 'scraplink' / 'settings.py'

env_vars = {}

with open(settings_path, 'r', encoding='utf-8') as f:
    for line in f:
        if 'SECRET_KEY' in line:
            match = re.search(r"SECRET_KEY\s*=\s*['\"](.+?)['\"]", line)
            if match:
                env_vars['SECRET_KEY'] = match.group(1)

        elif 'DEBUG' in line:
            match = re.search(r"DEBUG\s*=\s*(True|False)", line)
            if match:
                env_vars['DEBUG'] = match.group(1)

# الناتج
print("\n🔐 متغيرات البيئة الجاهزة:")
for key, value in env_vars.items():
    print(f'{key}="{value}"')

# إنشاء ملف .env
with open('.env', 'w', encoding='utf-8') as f:
    for key, value in env_vars.items():
        f.write(f'{key}="{value}"\n')

print("\n✅ تم إنشاء ملف .env بنجاح")
